int X,Y;

unsigned long timer1 = 0;

String inputString = "";         
bool stringComplete = false; 

void readSerial(){
  
  if(Serial3.available() > 0)
  {
//    uint16_t data = 0;
//    data = Serial2.read();
//    data |= Serial2.read() << 8;
//    char inChar = (char)data;
    char inChar = (char)Serial3.read();
    digitalWrite(LED_BUILTIN,HIGH);
    inputString += inChar;
    if (inChar == '\n') {
      stringComplete = true;
    }
  }
  if (stringComplete) 
  {
    if(inputString.startsWith("x"))
    {
//     Serial.print("X:");
     inputString.replace("x","");
     X=inputString.toInt();
//     Serial.println(X);
     inputString = "";
     stringComplete = false;
    }
  else if(inputString.startsWith("y"))
    {
//     Serial.print("Y:");
     inputString.replace("y","");
     Y=inputString.toInt();   // Y
//     Serial.println(Y);
     inputString = "";
     stringComplete = false;
    }
  }
//    if (millis() - timer1 > 50) 
//  {
//    Serial.print("X = "); Serial.print(X); Serial.print("\t");
//    Serial.print("Y = "); Serial.println(Y);
//    timer1 = millis();
//  }
}
